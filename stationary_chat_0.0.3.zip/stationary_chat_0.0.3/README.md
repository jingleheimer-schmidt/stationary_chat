## Stationary Chat
a mod for factorio
https://mods.factorio.com/mod/status_bars

---------------------
# Overview
This mod holds the chat/console window in place when the number of status bars visible to a player changes. This prevents the chat messages from moving up and down when the player mines something.
<!-- 
---------------------
# Features

---------------------
# Gallery

---------------------
## Companion Mods -->

---------------------
# Compatibility
There are currently no known mod compatibility issues. To report a compatibility issue, please make a post on the discussion page.

---------------------
# License
Stationary Chat © 2023 by asher_sky is licensed under Attribution-NonCommercial-ShareAlike 4.0 International.
To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/4.0/
