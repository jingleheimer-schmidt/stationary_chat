
local stationary_chat = {
    type = "bool-setting",
    name = "stationary_chat",
    setting_type = "startup",
    default_value = true,
    order = "stationary_chat"
}

data:extend {
    stationary_chat
}
